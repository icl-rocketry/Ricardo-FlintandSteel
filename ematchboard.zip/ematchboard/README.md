#Engine electronics - Sensor board
#Sensor board built off Ricardo and DAQ, adapted to USB C (2.0)
#up to 12 ch outputs at 250Hz max (at maximum oversampling rate of 16384) on continuous sampling mode
#Main files are Mainboard.pro/Mainboard.sch/analogue.sch/power.sch, ignore the other files 